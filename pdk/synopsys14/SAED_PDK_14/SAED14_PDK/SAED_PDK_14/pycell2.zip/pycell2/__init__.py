from n_fin import *
from n_fin_hv import *
from n_fin_lvt import *
from n_fin_ulvt import *
from p_fin import *
from p_fin_hv import *
from p_fin_lvt import *
from myinverter import *
from mynand import *
from tutorial4 import *
from diodes import *
from resistor import *

def definePcells(lib):
    lib.definePcell(n_fin,"n_fin") 
    lib.definePcell(diodes,"diodes")  
    lib.definePcell(resistor,"resistor") 
    #lib.definePcell(n_fin_ulvt,"nfinulvt") 
    #lib.definePcell(p_fin,"pfin")  
    #lib.definePcell(p_fin_hv,"pfinhv")
    #lib.definePcell(p_fin_lvt,"pfinlvt")
    #lib.definePcell(n_fin_ulvt,"pfinulvt")
    #lib.definePcell(myinverter,"myinverter") 
    #lib.definePcell(mynand,"mynand")
    #lib.definePcell(res,"resistor")
